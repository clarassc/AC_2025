﻿using System;

public class Exercicio6
{
    public static void Main()
    {
        // Solicita a nota final do aluno
        Console.Write("Digite a nota final do aluno: ");
        int nota = int.Parse(Console.ReadLine()); // Converte a entrada para número inteiro

        // Verifica a classificação com base na nota
        string classificacao;

        if (nota >= 90)
        {
            classificacao = "A";
        }
        else if (nota >= 80)
        {
            classificacao = "B";
        }
        else if (nota >= 70)
        {
            classificacao = "C";
        }
        else if (nota >= 60)
        {
            classificacao = "D";
        }
        else
        {
            classificacao = "F (Reprovado)";
        }

        // Exibe o resultado
        Console.WriteLine("A classificação do aluno é: " + classificacao);
    }
}
