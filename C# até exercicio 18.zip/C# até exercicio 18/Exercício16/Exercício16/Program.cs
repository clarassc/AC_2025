﻿using System;
 
public class Exercicio16
{
    public static void Main(string[] args)
    {
        parImpar(10);//Verifica o valor par
        parImpar(11);//Verifica o valor impar
    }

    //Método vazio para verificação par ou impar
    public static void parImpar(int valor1)
    {
        bool resultado = valor1 % 2 == 0;
        if (resultado) 
        {
            //Chamada do método que faz o quadrado do número
            quadradoNumPar(valor1);
        }
        else //Caso o numero seja impar...
        {
                Console.WriteLine("O número não é par e por" + "isso não é calculado o valor ao quadrado");
        }
    }

    //Método vazio de calcular o quadrado
    public static void quadradoNumPar(int valor2)
    {
        int resultado = valor2 * valor2;
        Console.WriteLine("O quadrado do valor" + valor2 + "é" + resultado);
    }


}