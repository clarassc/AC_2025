﻿using System;

public class Exercicio12
{
    public static void Main(string[] args)
    {
        int i = 1;

        do
        {
            Console.WriteLine(i);
            i++;
        } while (i <= 10);
    }
}