﻿using System;

public class Exercicio11
{
    public static void Main()
    {
        int soma = 0;   // Inicializa a soma
        int numero = 1; // Começa do número 1

        do
        {
            soma += numero; // Adiciona o número atual à soma
            numero++;       // Incrementa o número
        }
        while (soma < 100); // Continua enquanto a soma for menor que 100

        // Exibe os resultados
        Console.WriteLine("A soma acumulada é: " + soma);
        Console.WriteLine("O último número adicionado foi: " + (numero - 1));
    }
}
