﻿using System;

public class Exercicio10
{
    public static void Main()
    {
        int contador = 1; // Inicializa o contador
        int numero = 3;   // Número base (múltiplo de 3)

        while (contador <= 10) // Loop para exibir 10 múltiplos
        {
            Console.WriteLine(numero * contador); // Calcula e imprime o múltiplo
            contador++; // Incrementa o contador
        }
    }
}
