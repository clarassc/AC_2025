﻿using System;

public class Exercicio13
{
    public static void Main()
    {
        int numero = 1; // Inicializa a variável com 1

        do
        {
            Console.WriteLine(numero); // Imprime o número atual
            numero++; // Incrementa o número
        }
        while (numero <= 5); // Continua enquanto número for <= 5

        // Mensagem final após o loop
        Console.WriteLine("Contagem concluída!");
    }
}
