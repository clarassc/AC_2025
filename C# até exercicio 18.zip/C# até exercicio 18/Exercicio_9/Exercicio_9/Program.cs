﻿using System;

public class Exercicio9
{
    public static void Main()
    {
        int soma = 0; // Inicializa a variável para armazenar a soma

        // Loop de 1 a 50
        for (int i = 1; i <= 50; i++)
        {
            // Verifica se o número é ímpar
            if (i % 2 != 0)
            {
                soma += i; // Soma apenas os números ímpares
            }
        }

        // Exibe o resultado
        Console.WriteLine("A soma dos números ímpares entre 1 e 50 é: " + soma);
    }
}
