﻿using System;

public class Exercicio7
{
    public static void Main()
    {
        // Solicita a nota do aluno
        Console.Write("Digite a nota final do aluno (0 a 20): ");
        int nota = int.Parse(Console.ReadLine()); // Converte a entrada para número inteiro

        // Verifica a classificação com base na nota
        if (nota >= 18 && nota <= 20)
        {
            Console.WriteLine("Classificação: Excelente");
        }
        else if (nota >= 14 && nota <= 17)
        {
            Console.WriteLine("Classificação: Bom");
        }
        else if (nota >= 10 && nota <= 13)
        {
            Console.WriteLine("Classificação: Suficiente");
        }
        else if (nota >= 0 && nota <= 9)
        {
            Console.WriteLine("Classificação: Insuficiente");
        }
        else
        {
            Console.WriteLine("Nota inválida.");
        }
    }
}
